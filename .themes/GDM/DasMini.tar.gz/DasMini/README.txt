INFORMATION:
--------------------------------------------------------------------------------
  NAME:     "Das Mini"
  DATE:     March 10, 2009
  VERSION:  1.2
  AUTHOR: Ryan Johnson (CITguy) (rhino.citguy@gmail.com)
          Copyright 2009 Ryan Johnson (GPLv3)
	CHANGELOG:
		1.2
			- Label Text Fix

--------------------------------------------------------------------------------

  A copy of the GPLv3 should be included with the contents of this archive.
  If not, please visit the following URL to review the license.

    http://www.gnu.org/licenses/gpl-3.0.html

--------------------------------------------------------------------------------
